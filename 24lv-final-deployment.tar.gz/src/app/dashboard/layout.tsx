'use client'

import { Sidebar } from '@/components/layout/sidebar'

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {

  // Temporarily disable session check for testing
  // useEffect(() => {
  //   if (status === 'loading') return // Still loading

  //   if (!session) {
  //     router.push('/auth/login')
  //     return
  //   }
  // }, [session, status, router])

  // if (status === 'loading') {
  //   return (
  //     <div className="min-h-screen flex items-center justify-center">
  //       <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
  //     </div>
  //   )
  // }

  // Temporarily allow access without session for testing
  // if (!session) {
  //   return null
  // }

  return (
    <div className="flex h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="w-64 flex-shrink-0">
        <Sidebar />
      </div>
      <div className="flex-1 flex flex-col overflow-hidden">
        <main className="flex-1 overflow-y-auto p-6 bg-gradient-to-br from-slate-50/50 to-blue-50/50">
          {children}
        </main>
      </div>
    </div>
  )
}