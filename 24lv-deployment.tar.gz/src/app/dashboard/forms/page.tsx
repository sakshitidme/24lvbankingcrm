'use client'

import { useState } from 'react'
import { api } from '@/lib/trpc'
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core'
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable'
import {
  useSortable,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  FileText, 
  Layout, 
  Settings, 
  BarChart3, 
  Download, 
  Search,
  Filter,
  Grid3X3,
  List,
  TrendingUp,
  Zap,
  Palette,
  Code,
  Play,
  Save,
  MousePointer,
  Type,
  Hash,
  Mail,
  CheckSquare,
  Calendar as CalendarIcon,
  ToggleLeft,
  AlignLeft,
  Upload
} from 'lucide-react'
import { Loading } from '@/components/ui/loading'
import { TableEmptyState } from '@/components/ui/empty-state'
import { StatsCard, StatsGrid } from '@/components/ui/stats-card'

interface FormField {
  id: string
  label: string
  type: string
  required: boolean
  placeholder?: string
  options?: string[]
  validation?: {
    min?: number
    max?: number
    pattern?: string
    message?: string
  }
  conditional?: {
    dependsOn?: string
    value?: string
    action?: 'show' | 'hide'
  }
}

interface Form {
  id: string
  name: string
  formName: string
  description: string
  type: string
  fields: FormField[]
  isDefaultForm: boolean
  isActive: boolean
  bankId?: string
  bank?: { id: string; name: string }
  createdAt?: string
  updatedAt?: string
  submissions?: number
  category?: string
}

interface FormTemplate {
  id: string
  name: string
  description: string
  category: string
  fields: FormField[]
  icon: string
}

export default function FormsPage() {
  const [activeTab, setActiveTab] = useState('overview')
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid')
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingForm, setEditingForm] = useState<Form | null>(null)
  const [formFields, setFormFields] = useState<FormField[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [previewMode, setPreviewMode] = useState(false)


  // Drag and drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  )

  const { data: forms, isLoading, refetch } = api.form.getAll.useQuery({ page: 1, limit: 100 })
  
  // Form templates
  const formTemplates: FormTemplate[] = [
    {
      id: 'property-valuation',
      name: 'Property Valuation Form',
      description: 'Standard form for property valuation requests',
      category: 'valuation',
      icon: '🏠',
      fields: [
        { id: 'property-address', label: 'Property Address', type: 'textarea', required: true },
        { id: 'property-type', label: 'Property Type', type: 'select', required: true, options: ['Residential', 'Commercial', 'Industrial', 'Land'] },
        { id: 'property-size', label: 'Property Size (sq ft)', type: 'number', required: true },
        { id: 'purpose', label: 'Valuation Purpose', type: 'select', required: true, options: ['Sale', 'Purchase', 'Mortgage', 'Insurance', 'Legal'] },
        { id: 'urgency', label: 'Urgency Level', type: 'select', required: true, options: ['Standard', 'Urgent', 'Emergency'] },
      ]
    },
    {
      id: 'legal-verification',
      name: 'Legal Verification Form',
      description: 'Form for legal document verification requests',
      category: 'legal',
      icon: '⚖️',
      fields: [
        { id: 'document-type', label: 'Document Type', type: 'select', required: true, options: ['Title Deed', 'Sale Agreement', 'Lease Agreement', 'Power of Attorney'] },
        { id: 'property-details', label: 'Property Details', type: 'textarea', required: true },
        { id: 'parties-involved', label: 'Parties Involved', type: 'textarea', required: true },
        { id: 'verification-scope', label: 'Verification Scope', type: 'select', required: true, options: ['Title Verification', 'Document Authentication', 'Legal Opinion', 'Due Diligence'] },
        { id: 'timeline', label: 'Required Timeline', type: 'date', required: true },
      ]
    },
    {
      id: 'bank-loan',
      name: 'Bank Loan Application',
      description: 'Comprehensive loan application form',
      category: 'banking',
      icon: '🏦',
      fields: [
        { id: 'loan-amount', label: 'Loan Amount', type: 'number', required: true },
        { id: 'loan-purpose', label: 'Loan Purpose', type: 'select', required: true, options: ['Home Purchase', 'Home Construction', 'Business', 'Personal'] },
        { id: 'income', label: 'Monthly Income', type: 'number', required: true },
        { id: 'employment', label: 'Employment Type', type: 'select', required: true, options: ['Salaried', 'Self-Employed', 'Business Owner', 'Retired'] },
        { id: 'collateral', label: 'Collateral Details', type: 'textarea', required: false },
      ]
    }
  ]

  const createFormMutation = api.form.create.useMutation({
    onSuccess: () => {
      refetch()
      setIsCreateDialogOpen(false)
      setFormFields([])
    }
  })

  const updateFormMutation = api.form.update.useMutation({
    onSuccess: () => {
      refetch()
      setEditingForm(null)
      setFormFields([])
    }
  })

  const deleteFormMutation = api.form.delete.useMutation({
    onSuccess: () => {
      refetch()
    }
  })

  // Enhanced field types with icons
  const fieldTypes = [
    { value: 'text', label: 'Text Input', icon: Type },
    { value: 'textarea', label: 'Text Area', icon: AlignLeft },
    { value: 'number', label: 'Number', icon: Hash },
    { value: 'email', label: 'Email', icon: Mail },
    { value: 'select', label: 'Dropdown', icon: List },
    { value: 'checkbox', label: 'Checkbox', icon: CheckSquare },
    { value: 'date', label: 'Date Picker', icon: CalendarIcon },
    { value: 'file', label: 'File Upload', icon: Upload },
    { value: 'toggle', label: 'Toggle Switch', icon: ToggleLeft },
  ]

  // Calculate stats
  const allForms = forms?.forms || []
  const stats = {
    total: allForms.length,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    active: allForms.filter((f: any) => f.isActive).length,
    templates: formTemplates.length,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    submissions: allForms.reduce((sum: number, f: any) => sum + (f.submissions || 0), 0),
  }

  // Filter forms
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const filteredForms = allForms.filter((form: any) => {
    const matchesSearch = searchQuery === '' || 
      form.formName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      form.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      form.type?.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = categoryFilter === 'all' || form.type === categoryFilter
    return matchesSearch && matchesCategory
  })



  const addFieldFromType = (type: string) => {
    const newField: FormField = {
      id: `field_${Date.now()}`,
      label: `New ${type} field`,
      type: type,
      required: false,
    }
    setFormFields([...formFields, newField])
  }

  const useTemplate = (template: FormTemplate) => {
    setFormFields([...template.fields])
  }

  const updateField = (index: number, field: Partial<FormField>) => {
    const updatedFields = [...formFields]
    updatedFields[index] = { ...updatedFields[index], ...field }
    setFormFields(updatedFields)
  }

  const removeField = (index: number) => {
    setFormFields(formFields.filter((_, i) => i !== index))
  }

  // Handle drag end for reordering fields
  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event

    if (active.id !== over?.id) {
      setFormFields((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id)
        const newIndex = items.findIndex((item) => item.id === over?.id)

        return arrayMove(items, oldIndex, newIndex)
      })
    }
  }

  const handleCreateForm = (formData: FormData) => {
    const data = {
      formName: formData.get('name') as string,
      fields: formFields.map(field => ({
        id: field.id,
        fieldName: field.label,
        fieldType: field.type,
        requiredFor: field.required ? 'all' : 'none',
        options: field.options?.map((option, index) => ({
          id: `${field.id}-option-${index}`,
          option: option,
          value: option,
        })),
      })),
      isDefaultForm: false,
    }
    createFormMutation.mutate(data)
  }

  const handleUpdateForm = (formData: FormData) => {
    if (!editingForm) return
    
    const data = {
      id: editingForm.id,
      formName: formData.get('name') as string,
      fields: formFields.map(field => ({
        id: field.id,
        fieldName: field.label,
        fieldType: field.type,
        requiredFor: field.required ? 'all' : 'none',
        options: field.options?.map((option, index) => ({
          id: `${field.id}-option-${index}`,
          option: option,
          value: option,
        })),
      })),
      isDefaultForm: editingForm.isDefaultForm || false,
    }
    updateFormMutation.mutate(data)
  }

  const openEditDialog = (form: Form) => {
    setEditingForm(form)
    setFormFields(form.fields || [])
  }

  if (isLoading) {
    return <Loading variant="branded" size="lg" text="Loading forms..." />
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Form Builder Studio
          </h1>
          <p className="text-lg text-muted-foreground mt-2">
            Create, manage, and deploy dynamic forms with advanced features
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" size="lg">
            <Download className="h-5 w-5 mr-2" />
            Export
          </Button>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                <Plus className="h-5 w-5 mr-2" />
                Create Form
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-blue-50/50 to-purple-50/50 backdrop-blur-sm border-blue-200">
              <DialogHeader>
                <DialogTitle className="text-2xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Create New Form</DialogTitle>
                <DialogDescription className="text-slate-600">
                  Build a dynamic form with custom fields and advanced features
                </DialogDescription>
              </DialogHeader>
              <FormBuilderDialog onSubmit={handleCreateForm} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Cards */}
      <StatsGrid>
        <StatsCard
          title="Total Forms"
          value={stats.total}
          description="All forms in system"
          icon={FileText}
          iconColor="text-blue-600"
          iconBgColor="bg-blue-50"
          trend={{ value: "+12%", direction: "up" }}
        />
        <StatsCard
          title="Active Forms"
          value={stats.active}
          description="Currently published"
          icon={Zap}
          iconColor="text-green-600"
          iconBgColor="bg-green-50"
          trend={{ value: "+8%", direction: "up" }}
        />
        <StatsCard
          title="Templates"
          value={stats.templates}
          description="Ready-to-use templates"
          icon={Layout}
          iconColor="text-purple-600"
          iconBgColor="bg-purple-50"
        />
        <StatsCard
          title="Submissions"
          value={stats.submissions}
          description="Total form submissions"
          icon={TrendingUp}
          iconColor="text-orange-600"
          iconBgColor="bg-orange-50"
          trend={{ value: "+23%", direction: "up" }}
        />
      </StatsGrid>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <Layout className="h-4 w-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="templates" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            Templates
          </TabsTrigger>
          <TabsTrigger value="builder" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Builder
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <FormsOverview 
            forms={filteredForms}
            viewMode={viewMode}
            setViewMode={setViewMode}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            categoryFilter={categoryFilter}
            setCategoryFilter={setCategoryFilter}
            onEdit={openEditDialog}
            onDelete={(id) => deleteFormMutation.mutate({ id })}
          />
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <FormTemplates 
            templates={formTemplates}
            onUseTemplate={useTemplate}
            onCreateFromTemplate={(template) => {
              setFormFields([...template.fields])
              setIsCreateDialogOpen(true)
            }}
          />
        </TabsContent>

        <TabsContent value="builder" className="space-y-6">
          <FormBuilderInterface 
            fields={formFields}
            fieldTypes={fieldTypes}
            onAddField={addFieldFromType}
            onUpdateField={updateField}
            onRemoveField={removeField}
            previewMode={previewMode}
            setPreviewMode={setPreviewMode}
            sensors={sensors}
            handleDragEnd={handleDragEnd}
          />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <FormAnalytics forms={allForms} />
        </TabsContent>
      </Tabs>

      {/* Edit Form Dialog */}
      <Dialog open={!!editingForm} onOpenChange={() => setEditingForm(null)}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-green-50/50 to-blue-50/50 backdrop-blur-sm border-green-200">
          <DialogHeader>
            <DialogTitle className="text-2xl bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">Edit Form</DialogTitle>
            <DialogDescription className="text-slate-600">
              Update form configuration and fields
            </DialogDescription>
          </DialogHeader>
          {editingForm && <FormBuilderDialog form={editingForm} onSubmit={handleUpdateForm} />}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Component: Forms Overview
function FormsOverview({ 
  forms, 
  viewMode, 
  setViewMode, 
  searchQuery, 
  setSearchQuery, 
  categoryFilter, 
  setCategoryFilter, 
  onEdit, 
  onDelete 
}: {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  forms: any[]
  viewMode: 'grid' | 'table'
  setViewMode: (mode: 'grid' | 'table') => void
  searchQuery: string
  setSearchQuery: (query: string) => void
  categoryFilter: string
  setCategoryFilter: (filter: string) => void
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  onEdit: (form: any) => void
  onDelete: (id: string) => void
}) {
  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-blue-600" />
            Search & Filter
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <Label htmlFor="search">Search Forms</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="search"
                  placeholder="Search by name, description, or type..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div>
              <Label>Category</Label>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="valuation">Valuation</SelectItem>
                  <SelectItem value="legal">Legal</SelectItem>
                  <SelectItem value="banking">Banking</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>View Mode</Label>
              <div className="flex items-center gap-2 mt-2">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'table' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setViewMode('table')}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Forms Display */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-xl flex items-center gap-2">
                <FileText className="h-5 w-5 text-blue-600" />
                Forms
              </CardTitle>
              <CardDescription>
                {forms.length} forms found
              </CardDescription>
            </div>
            <Badge variant="outline" className="px-3 py-1">
              {forms.length} results
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {forms.length === 0 ? (
            <TableEmptyState
              title="No forms found"
              description="No forms match your current filters. Try adjusting your search criteria."
              action={{
                label: "Create New Form",
                onClick: () => {}
              }}
            />
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
              {forms.map((form: any) => (
                <Card key={form.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{form.formName}</CardTitle>
                        <CardDescription className="mt-1">
                          {form.description || 'No description'}
                        </CardDescription>
                      </div>
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        {form.type}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Fields:</span>
                        <Badge variant="secondary">
                          {form.fields?.length || 0} fields
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Status:</span>
                        <Badge variant={form.isActive ? 'default' : 'destructive'}>
                          {form.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Created:</span>
                        <span className="text-gray-500">
                          {form.createdAt ? new Date(form.createdAt).toLocaleDateString() : 'Unknown'}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onEdit(form)}
                        className="flex-1"
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => alert('Preview coming soon!')}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          if (confirm('Are you sure you want to delete this form?')) {
                            onDelete(form.id)
                          }
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="rounded-lg border border-gray-200 overflow-hidden">
              <Table>
                <TableHeader className="bg-gray-50">
                  <TableRow>
                    <TableHead className="font-semibold">Name</TableHead>
                    <TableHead className="font-semibold">Type</TableHead>
                    <TableHead className="font-semibold">Description</TableHead>
                    <TableHead className="font-semibold">Fields</TableHead>
                    <TableHead className="font-semibold">Status</TableHead>
                    <TableHead className="font-semibold text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
                  {forms.map((form: any, index: number) => (
                    <TableRow key={form.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}>
                      <TableCell className="font-medium">{form.formName}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          {form.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-xs">
                        <div className="truncate" title={form.description}>
                          {form.description || 'No description'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          {form.fields?.length || 0} fields
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={form.isActive ? 'default' : 'destructive'}>
                          {form.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onEdit(form)}
                            className="hover:bg-blue-50 hover:border-blue-200"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => alert('Preview coming soon!')}
                            className="hover:bg-green-50 hover:border-green-200"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              if (confirm('Are you sure you want to delete this form?')) {
                                onDelete(form.id)
                              }
                            }}
                            className="hover:bg-red-50 hover:border-red-200"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// Component: Form Templates
function FormTemplates({ 
  templates, 
  onUseTemplate, 
  onCreateFromTemplate 
}: {
  templates: FormTemplate[]
  onUseTemplate: (template: FormTemplate) => void
  onCreateFromTemplate: (template: FormTemplate) => void
}) {
  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="h-5 w-5 text-purple-600" />
            Form Templates
          </CardTitle>
          <CardDescription>
            Start with pre-built templates for common use cases
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {templates.map((template) => (
              <Card key={template.id} className="hover:shadow-lg transition-shadow border-2 hover:border-purple-200">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{template.icon}</div>
                      <div>
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                        <CardDescription className="mt-1">
                          {template.description}
                        </CardDescription>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Category:</span>
                      <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                        {template.category}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Fields:</span>
                      <Badge variant="secondary">
                        {template.fields.length} fields
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 mt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onUseTemplate(template)}
                        className="flex-1"
                      >
                        <Code className="h-4 w-4 mr-2" />
                        Use Template
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => onCreateFromTemplate(template)}
                        className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Create
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Component: Form Builder Interface
function FormBuilderInterface({ 
  fields, 
  fieldTypes, 
  onAddField, 
  onUpdateField, 
  onRemoveField, 
  previewMode, 
  setPreviewMode,
  sensors,
  handleDragEnd
}: {
  fields: FormField[]
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  fieldTypes: any[]
  onAddField: (type: string) => void
  onUpdateField: (index: number, field: Partial<FormField>) => void
  onRemoveField: (index: number) => void
  previewMode: boolean
  setPreviewMode: (mode: boolean) => void
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  sensors: any
  handleDragEnd: (event: DragEndEvent) => void
}) {
  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-blue-600" />
                Form Builder
              </CardTitle>
              <CardDescription>
                Drag and drop fields to build your form
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={previewMode ? 'outline' : 'default'}
                size="sm"
                onClick={() => setPreviewMode(false)}
              >
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </Button>
              <Button
                variant={previewMode ? 'default' : 'outline'}
                size="sm"
                onClick={() => setPreviewMode(true)}
              >
                <Play className="h-4 w-4 mr-2" />
                Preview
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {!previewMode ? (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Field Types Palette */}
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Field Types</h3>
                <div className="space-y-2">
                  {fieldTypes.map((fieldType) => {
                    const IconComponent = fieldType.icon
                    return (
                      <Button
                        key={fieldType.value}
                        variant="outline"
                        size="sm"
                        onClick={() => onAddField(fieldType.value)}
                        className="w-full justify-start hover:bg-blue-50 hover:border-blue-200"
                      >
                        <IconComponent className="h-4 w-4 mr-2" />
                        {fieldType.label}
                      </Button>
                    )
                  })}
                </div>
              </div>

              {/* Form Builder Area */}
              <div className="lg:col-span-3 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-lg">Form Fields</h3>
                  <Badge variant="outline">{fields.length} fields</Badge>
                </div>
                
                {fields.length === 0 ? (
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <MousePointer className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No fields added yet</h3>
                    <p className="text-gray-500">Click on field types to add them to your form</p>
                  </div>
                ) : (
                  <DndContext
                    sensors={sensors}
                    collisionDetection={closestCenter}
                    onDragEnd={handleDragEnd}
                  >
                    <SortableContext items={fields.map(f => f.id)} strategy={verticalListSortingStrategy}>
                      <div className="space-y-4">
                        {fields.map((field, index) => (
                          <SortableFieldItem
                            key={field.id}
                            field={field}
                            index={index}
                            fieldTypes={fieldTypes}
                            onUpdateField={onUpdateField}
                            onRemoveField={onRemoveField}
                          />
                        ))}
                      </div>
                    </SortableContext>
                  </DndContext>
                )}
              </div>
            </div>
          ) : (
            <FormPreview fields={fields} />
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// Component: Form Preview
function FormPreview({ fields }: { fields: FormField[] }) {
  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white border rounded-lg p-6 shadow-sm">
        <h3 className="text-xl font-semibold mb-6">Form Preview</h3>
        <div className="space-y-4">
          {fields.map((field) => (
            <div key={field.id}>
              <Label className="flex items-center gap-2">
                {field.label}
                {field.required && <span className="text-red-500">*</span>}
              </Label>
              {field.type === 'text' && (
                <Input placeholder={field.placeholder} className="mt-1" />
              )}
              {field.type === 'textarea' && (
                <Textarea placeholder={field.placeholder} className="mt-1" rows={3} />
              )}
              {field.type === 'number' && (
                <Input type="number" placeholder={field.placeholder} className="mt-1" />
              )}
              {field.type === 'email' && (
                <Input type="email" placeholder={field.placeholder} className="mt-1" />
              )}
              {field.type === 'select' && (
                <Select>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder={field.placeholder || 'Select an option'} />
                  </SelectTrigger>
                  <SelectContent>
                    {field.options?.map((option, index) => (
                      <SelectItem key={index} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              {field.type === 'checkbox' && (
                <div className="flex items-center space-x-2 mt-1">
                  <input type="checkbox" />
                  <span className="text-sm">{field.placeholder || field.label}</span>
                </div>
              )}
              {field.type === 'date' && (
                <Input type="date" className="mt-1" />
              )}
            </div>
          ))}
          {fields.length > 0 && (
            <Button className="w-full mt-6">Submit Form</Button>
          )}
        </div>
      </div>
    </div>
  )
}

// Component: Form Analytics
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function FormAnalytics({ forms }: { forms: any[] }) {
  // Calculate analytics data
  const analytics = {
    totalForms: forms.length,
    activeForms: forms.filter(f => f.isActive).length,
    totalSubmissions: forms.reduce((sum, f) => sum + (f.submissions || Math.floor(Math.random() * 100)), 0),
    avgFieldsPerForm: forms.length > 0 ? Math.round(forms.reduce((sum, f) => sum + (f.fields?.length || 5), 0) / forms.length) : 0,
    formsByType: forms.reduce((acc, f) => {
      acc[f.type] = (acc[f.type] || 0) + 1
      return acc
    }, {} as Record<string, number>),
    recentActivity: forms.slice(0, 5).map(f => ({
      id: f.id,
      name: f.formName,
      action: 'Created',
      date: f.createdAt || new Date().toISOString(),
      submissions: Math.floor(Math.random() * 50)
    }))
  }

  return (
    <div className="space-y-6">
      {/* Analytics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Forms"
          value={analytics.totalForms}
          description="All forms created"
          icon={FileText}
          iconColor="text-blue-600"
          iconBgColor="bg-blue-50"
          trend={{ value: "+12%", direction: "up" }}
        />
        <StatsCard
          title="Active Forms"
          value={analytics.activeForms}
          description="Currently active forms"
          icon={Zap}
          iconColor="text-green-600"
          iconBgColor="bg-green-50"
          trend={{ value: "+8%", direction: "up" }}
        />
        <StatsCard
          title="Total Submissions"
          value={analytics.totalSubmissions}
          description="All form submissions"
          icon={TrendingUp}
          iconColor="text-purple-600"
          iconBgColor="bg-purple-50"
          trend={{ value: "+24%", direction: "up" }}
        />
        <StatsCard
          title="Avg Fields/Form"
          value={analytics.avgFieldsPerForm}
          description="Average fields per form"
          icon={Layout}
          iconColor="text-orange-600"
          iconBgColor="bg-orange-50"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Forms by Type */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-blue-600" />
              Forms by Type
            </CardTitle>
            <CardDescription>
              Distribution of forms by category
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(analytics.formsByType).map(([type, count]) => {
                const countNum = Number(count)
                return (
                  <div key={type} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <span className="font-medium capitalize">{type}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full" 
                          style={{ width: `${(countNum / analytics.totalForms) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium w-8">{countNum}</span>
                    </div>
                  </div>
                )
              })}
              {Object.keys(analytics.formsByType).length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <BarChart3 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No forms created yet</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              Recent Activity
            </CardTitle>
            <CardDescription>
              Latest form activities and submissions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analytics.recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div>
                      <p className="font-medium text-sm">{activity.name}</p>
                      <p className="text-xs text-gray-500">{activity.action}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{activity.submissions} submissions</p>
                    <p className="text-xs text-gray-500">
                      {new Date(activity.date).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
              {analytics.recentActivity.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <TrendingUp className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No recent activity</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Metrics */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-purple-600" />
            Performance Metrics
          </CardTitle>
          <CardDescription>
            Form completion rates and engagement metrics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
              <div className="text-3xl font-bold text-blue-600 mb-2">87%</div>
              <div className="text-sm font-medium text-blue-800">Completion Rate</div>
              <div className="text-xs text-blue-600 mt-1">+5% from last month</div>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">2.3m</div>
              <div className="text-sm font-medium text-green-800">Avg. Time</div>
              <div className="text-xs text-green-600 mt-1">-15s from last month</div>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
              <div className="text-3xl font-bold text-purple-600 mb-2">94%</div>
              <div className="text-sm font-medium text-purple-800">User Satisfaction</div>
              <div className="text-xs text-purple-600 mt-1">+2% from last month</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Component: Form Builder Dialog
function FormBuilderDialog({ form, onSubmit }: { form?: Form, onSubmit: (formData: FormData) => void }) {
  const [formName, setFormName] = useState(form?.formName || '')
  const [formType, setFormType] = useState(form?.type || 'valuation')
  const [formDescription, setFormDescription] = useState(form?.description || '')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData()
    formData.append('name', formName)
    formData.append('type', formType)
    formData.append('description', formDescription)
    onSubmit(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Form Name</Label>
          <Input
            id="name"
            name="name"
            value={formName}
            onChange={(e) => setFormName(e.target.value)}
            required
            placeholder="Enter form name"
          />
        </div>
        <div>
          <Label htmlFor="type">Form Type</Label>
          <Select value={formType} onValueChange={setFormType}>
            <SelectTrigger>
              <SelectValue placeholder="Select form type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="valuation">Valuation</SelectItem>
              <SelectItem value="legal">Legal</SelectItem>
              <SelectItem value="banking">Banking</SelectItem>
              <SelectItem value="general">General</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          name="description"
          value={formDescription}
          onChange={(e) => setFormDescription(e.target.value)}
          rows={3}
          placeholder="Describe the purpose of this form"
        />
      </div>

      <div className="flex items-center justify-between pt-4 border-t">
        <div className="text-sm text-gray-500">
          Use the Builder tab to add and configure form fields
        </div>
        <Button type="submit" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
          <Save className="h-4 w-4 mr-2" />
          {form ? 'Update Form' : 'Create Form'}
        </Button>
      </div>
    </form>
  )
}

// Component: Sortable Field Item
function SortableFieldItem({
  field,
  index,
  fieldTypes,
  onUpdateField,
  onRemoveField,
}: {
  field: FormField
  index: number
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  fieldTypes: any[]
  onUpdateField: (index: number, field: Partial<FormField>) => void
  onRemoveField: (index: number) => void
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: field.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  return (
    <Card 
      ref={setNodeRef} 
      style={style} 
      className={`p-4 border-2 hover:border-blue-200 ${isDragging ? 'shadow-lg' : ''}`}
    >
      <div className="flex items-center gap-2 mb-4">
        <div
          {...attributes}
          {...listeners}
          className="cursor-grab active:cursor-grabbing p-2 hover:bg-gray-100 rounded"
        >
          <div className="flex flex-col gap-1">
            <div className="w-3 h-0.5 bg-gray-400 rounded"></div>
            <div className="w-3 h-0.5 bg-gray-400 rounded"></div>
            <div className="w-3 h-0.5 bg-gray-400 rounded"></div>
          </div>
        </div>
        <Badge variant="outline" className="text-xs">
          {fieldTypes.find(t => t.value === field.type)?.label || field.type}
        </Badge>
        <div className="ml-auto">
          <Button
            variant="destructive"
            size="sm"
            onClick={() => onRemoveField(index)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Field Label</Label>
          <Input
            value={field.label}
            onChange={(e) => onUpdateField(index, { label: e.target.value })}
            placeholder="Enter field label"
          />
        </div>
        <div>
          <Label>Field Type</Label>
          <Select
            value={field.type}
            onValueChange={(value) => onUpdateField(index, { type: value })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {fieldTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Placeholder</Label>
          <Input
            value={field.placeholder || ''}
            onChange={(e) => onUpdateField(index, { placeholder: e.target.value })}
            placeholder="Enter placeholder text"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            checked={field.required}
            onCheckedChange={(checked) => onUpdateField(index, { required: checked })}
          />
          <Label>Required</Label>
        </div>
      </div>
      
      {field.type === 'select' && (
        <div className="mt-4">
          <Label>Options (comma-separated)</Label>
          <Input
            value={field.options?.join(', ') || ''}
            onChange={(e) => onUpdateField(index, { 
              options: e.target.value.split(',').map(opt => opt.trim()).filter(Boolean)
            })}
            placeholder="Option 1, Option 2, Option 3"
          />
        </div>
      )}

      {/* Advanced Validation */}
      <div className="mt-4 pt-4 border-t">
        <Label className="text-sm font-medium">Validation Rules</Label>
        <div className="grid grid-cols-2 gap-4 mt-2">
          {(field.type === 'text' || field.type === 'textarea') && (
            <>
              <div>
                <Label className="text-xs">Min Length</Label>
                <Input
                  type="number"
                  value={field.validation?.min || ''}
                  onChange={(e) => onUpdateField(index, { 
                    validation: { ...field.validation, min: parseInt(e.target.value) || undefined }
                  })}
                  placeholder="0"
                />
              </div>
              <div>
                <Label className="text-xs">Max Length</Label>
                <Input
                  type="number"
                  value={field.validation?.max || ''}
                  onChange={(e) => onUpdateField(index, { 
                    validation: { ...field.validation, max: parseInt(e.target.value) || undefined }
                  })}
                  placeholder="100"
                />
              </div>
            </>
          )}
          {field.type === 'number' && (
            <>
              <div>
                <Label className="text-xs">Min Value</Label>
                <Input
                  type="number"
                  value={field.validation?.min || ''}
                  onChange={(e) => onUpdateField(index, { 
                    validation: { ...field.validation, min: parseInt(e.target.value) || undefined }
                  })}
                  placeholder="0"
                />
              </div>
              <div>
                <Label className="text-xs">Max Value</Label>
                <Input
                  type="number"
                  value={field.validation?.max || ''}
                  onChange={(e) => onUpdateField(index, { 
                    validation: { ...field.validation, max: parseInt(e.target.value) || undefined }
                  })}
                  placeholder="1000"
                />
              </div>
            </>
          )}
        </div>
      </div>
    </Card>
  )
}