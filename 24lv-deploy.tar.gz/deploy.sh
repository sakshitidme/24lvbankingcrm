#!/bin/bash

echo "🚀 24LV App - Vercel Deployment Script"
echo "======================================"

# Check if Vercel CLI is installed
if ! command -v vercel &> /dev/null; then
    echo "📦 Installing Vercel CLI..."
    npm install -g vercel
fi

# Check if user is logged in to Vercel
echo "🔐 Please make sure you're logged in to Vercel..."
echo "Run: vercel login"
echo ""

# Build the application locally first
echo "🏗️  Building application locally..."
npm run build

if [ $? -eq 0 ]; then
    echo "✅ Local build successful!"
else
    echo "❌ Local build failed. Please fix errors before deploying."
    exit 1
fi

echo ""
echo "🚀 Ready to deploy to Vercel!"
echo ""
echo "Next steps:"
echo "1. Run: vercel login"
echo "2. Run: vercel"
echo "3. Follow the prompts"
echo "4. Set up environment variables in Vercel dashboard"
echo "5. Set up your database"
echo ""
echo "📋 Required Environment Variables:"
echo "- DATABASE_URL"
echo "- NEXTAUTH_SECRET"
echo "- NEXTAUTH_URL"
echo "- BLOB_READ_WRITE_TOKEN (optional)"
echo ""
echo "📖 See DEPLOYMENT.md for detailed instructions"